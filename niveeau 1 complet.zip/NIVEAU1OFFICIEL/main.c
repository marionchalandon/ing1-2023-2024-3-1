#include <stdio.h>
#include <stdbool.h>
#include <conio.h>
#include <windows.h>
#include <process.h> // Ajout de la bibliothèque pour les threads

void hideCursor() { //fonction qui permet de cacher le curseur de la souris, pour un affichage plus agréable
    CONSOLE_CURSOR_INFO cursorInfo;
    cursorInfo.bVisible = false;
    cursorInfo.dwSize = 100;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
}

// Fonction du chronomètre
void Chronometre(void* params) {
    int* tempsRestant = (int*)params;

    while (*tempsRestant > 0) {
        Sleep(1000);  // Attendre 1 seconde
        (*tempsRestant)--;
    }
}

int main() {
    hideCursor();  // Masquer le curseur

    int largeur = 20;
    int hauteur = 10;
    char cadre[hauteur][largeur];
    int positionY = 5; // Position initiale X du pion (lignes)
    int positionX = 10; // Position initiale Y du pion (colonnes)
    int vCount = 4; // Nombre de 'V' restants
    int blocPousseY = -1; // Variables pour suivre la direction de poussée
    int blocPousseX = -1;
    bool blocsPousses[hauteur][largeur];
    int score = 0;

    // Remplir le tableau et faire le cadre de X
    for (int i = 0; i < hauteur; i++) {
        for (int j = 0; j < largeur; j++) {
            if (j == 0 || j == largeur - 1) {
                cadre[i][j] = 'X';
            } else if (i == 0 || i == hauteur - 1) {
                cadre[i][j] = 'X';
            } else {
                cadre[i][j] = ' ';
            }
            // Ajout des 'V' à chaque coin du cadre à l'intérieur
            if ((i == 1 && (j == 1 || j == largeur - 2)) || (i == hauteur - 2 && (j == 1 || j == largeur - 2))) {
                cadre[i][j] = 'V';
            }
        }
    }

    for (int i = 0; i < hauteur; i++) { //initialisé les blocs non poussés
        for (int j = 0; j < largeur; j++) {
            blocsPousses[i][j] = false;
        }
    }

    // Placer le pion au centre du tableau
    cadre[positionY][positionX] = 'S';
    cadre[5][9] = '#'; //affichage des blocs poussables autour de snoopy
    cadre[5][11] = '#';
    cadre[4][10] = '#';
    cadre[6][10] = '#';

    cadre[2][1] = 'C'; //affichage des blocs cassables
    cadre[1][2] = 'C';

    cadre[7][2] = '$'; //affichage des blocs piégés
    cadre[6][2] = '$';
    cadre[7][3] = '$';

    int tempsRestant = 120; // Chronomètre de 120 secondes

    // Créer un thread pour le chronomètre
    _beginthread(Chronometre, 0, &tempsRestant);

    while (tempsRestant > 0) {
        system("cls"); // Effacer l'écran

        printf("Temps restant : %d secondes\n", tempsRestant);
        // Afficher le tableau car boucle
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 20; j++) {
                printf("%c", cadre[i][j]);
            }
            printf("\n");
        }

        int a = 0;
        if (_kbhit()) {
            a = getch();
        }

        printf("Deplacez le pion avec les flèches, q (revenir au menu principal): ");
        printf("%d", a);

        // Effacer la position actuelle du pion
        cadre[positionY][positionX] = ' ';

        // Mettre à jour la position du pion en fonction du déplacement
        if (a == 72 && positionY > 1 && !blocsPousses[positionY - 1][positionX] &&
            cadre[positionY - 1][positionX] != 'C') { //fleche du haut et on blinde pour pas sortir du cadre
            positionY--;
            blocPousseY = -1; // Pousse vers le haut
            blocPousseX = 0;
        } else if (a == 80 && positionY < hauteur - 2 && !blocsPousses[positionY + 1][positionX] &&
                   cadre[positionY + 1][positionX] != 'C') { //fleche du bas et on blinde pour pas sortir du cadre
            positionY++;
            blocPousseY = 1; // Pousse vers le bas
            blocPousseX = 0;
        } else if (a == 75 && positionX > 1 && !blocsPousses[positionY][positionX - 1] &&
                   cadre[positionY][positionX - 1] != 'C') { //fleche de gauche et on blinde pour pas sortir du cadre
            positionX--;
            blocPousseY = 0;
            blocPousseX = -1; // Pousse vers la gauche
        } else if (a == 77 && positionX < largeur - 2 && !blocsPousses[positionY][positionX + 1] &&
                   cadre[positionY][positionX + 1] != 'C') { //fleche de droite et on blinde pour pas sortir du cadre
            positionX++;
            blocPousseY = 0;
            blocPousseX = 1; // Pousse vers la droite
        } else if (a == 'q') {
            break; // Quitter le programme si 'q' est appuyé
        } else if (a == 'c') { // Si la touche "c" est pressée
            // Vérifiez si le pion est sur une case adjacente à un bloc "C"
            if ((positionY > 1 && cadre[positionY - 1][positionX] == 'C') ||
                (positionY < hauteur - 2 && cadre[positionY + 1][positionX] == 'C') ||
                (positionX > 1 && cadre[positionY][positionX - 1] == 'C') ||
                (positionX < largeur - 2 && cadre[positionY][positionX + 1] == 'C')) {
                // Vérifiez et supprimez les blocs "C" adjacents
                if (positionY > 1 && cadre[positionY - 1][positionX] == 'C') {
                    cadre[positionY - 1][positionX] = ' ';
                }
                if (positionY < hauteur - 2 && cadre[positionY + 1][positionX] == 'C') {
                    cadre[positionY + 1][positionX] = ' ';
                }
                if (positionX > 1 && cadre[positionY][positionX - 1] == 'C') {
                    cadre[positionY][positionX - 1] = ' ';
                }
                if (positionX < largeur - 2 && cadre[positionY][positionX + 1] == 'C') {
                    cadre[positionY][positionX + 1] = ' ';
                }
            }
        }

        if (cadre[positionY][positionX] == '#' && !blocsPousses[positionY][positionX] &&
            cadre[positionY + blocPousseY][positionX + blocPousseX] == ' ') {
            cadre[positionY + blocPousseY][positionX + blocPousseX] = '#';
            blocsPousses[positionY + blocPousseY][positionX + blocPousseX] = true;
            cadre[positionY][positionX] = ' ';
        }

        if (tempsRestant == 1) { //fonction si le le chrono arrive au bout
            system("cls");
            printf("Game over, le temps est écoulé\n");
            // Vous pouvez ajouter d'autres actions ici, par exemple, réinitialiser le jeu.
            printf("Appuyez sur une touche pour continuer...\n");
            getch(); // Attendre que l'utilisateur appuie sur une touche pour continuer
        }

        if ((cadre[positionY][positionX+1] == '$')||(cadre[positionY][positionX-1] == '$') || (cadre[positionY-1][positionX] == '$')||(cadre[positionY+1][positionX] == '$')) { //fonciton si on touche un piege
            system("cls");
            printf("Game over, vous avez touché un piège\n");
            // Vous pouvez ajouter d'autres actions ici, par exemple, réinitialiser le jeu.
            printf("Appuyez sur une touche pour continuer...\n");
            getch(); // Attendre que l'utilisateur appuie sur une touche pour continuer
        }

        if (cadre[positionY][positionX] == 'V') {
            cadre[positionY][positionX] = ' ';
            vCount--;
            if (vCount == 0) {
                system("cls"); // Effacer l'écran
                printf("Bravo ! Niveau réussi\n");
                score = tempsRestant * 100;
                printf("Score : %d\n", score);
                printf("Appuyez sur une touche pour quitter le jeu...\n");
                getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                break;
            }
        }

        // Mettre à jour la position du pion sur le tableau
        cadre[positionY][positionX] = 'S';
    }

    // Rétablir l'affichage du curseur à la fin du programme
    CONSOLE_CURSOR_INFO cursorInfo;
    cursorInfo.bVisible = true;
    cursorInfo.dwSize = 1;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);

    return 0;
}