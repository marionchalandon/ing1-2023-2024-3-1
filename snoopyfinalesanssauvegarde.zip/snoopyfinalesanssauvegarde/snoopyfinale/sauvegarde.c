#include "plus.h"

void nouvellePartie(int niveau, int tempsRestant, int score) {
    int choixPartie, reponse = 0;
    FILE *Sauve1, *Sauve2, *Sauve3;
    int niveau1Info, niveau2Info, niveau3Info;

    /*char cwd[PATH_MAX];
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("Current working dir: %s\n", cwd);
    } else {
        perror("getcwd() error");
        return 1;
    }*/
    //ouverture fichier

    Sauve1 = fopen("../Sauve1.txt", "r");
    Sauve2 = fopen("./Sauve2.txt", "r");
    Sauve3 = fopen("../Sauve3.txt", "r");

    //Se positionner pour trouver les infos du niveau
    fseek(Sauve1, 0, SEEK_SET);
    fseek(Sauve2, 0, SEEK_SET);
    fseek(Sauve3, 0, SEEK_SET);

    //lecture fichier utilisé?
    fscanf(Sauve1, "%d", &niveau1Info);
    fscanf(Sauve2, "%d", &niveau2Info);
    fscanf(Sauve3, "%d", &niveau3Info);

    //fermeture fichier lecture
    fclose(Sauve1);
    fclose(Sauve2);
    fclose(Sauve3);


        //choix de la sauvegarde

        do {
            clearScreen();

            printf("Veuillez choisir une sauvegarde pour votre nouvelle partie :\n");
            afficheSauvegarde();
            scanf("%d", &choixPartie);
        } while (choixPartie <= 0 || choixPartie > 3);

//choix de sauvegarde
        switch (choixPartie) {
            case 1:
                Sauve1=fopen("./Sauve1.txt", "w+");
                if (niveau1Info == 0) {


                    if (Sauve1 == NULL) {
                        printf("Erreur lors de l'ouverture du fichier pour sauvegarde du niveau 1.\n");
                        return;
                    }
                    fseek(Sauve1, 0, SEEK_SET);
                    fprintf(Sauve1, "%d %d %d ", niveau, tempsRestant, score);
                    fseek(Sauve1, 0, SEEK_END);
                    //appel de niveau 1
                    clearScreen();
                    niveau1opt2();

                } else if (niveau1Info != 0) {
                    printf("Cette sauvegarde est deja utilise voulez vous l'ecraser?\n");
                    printf("1.Oui\n");
                    printf("2.Non\n");
                    scanf("%d", &reponse);
                    switch (reponse) {
                        case 1 :
                            fseek(Sauve1, 0, SEEK_SET);
                            fprintf(Sauve1, "%d %d %d\n", 0, 0, 0);
                            fseek(Sauve1, 3 * sizeof(int), SEEK_END);
                            //appel de niveau 1
                            clearScreen();
                            niveau1opt2();
                            break;
                        case 2 :
                            clearScreen();
                            chargementSauvegarde();
                            break;
                    }
                }


            case 2:

                Sauve2=fopen("./Sauve2.txt", "w+");
                if (niveau2Info == 0) {


                    if (Sauve2 == NULL) {
                        printf("Erreur lors de l'ouverture du fichier pour sauvegarde du niveau 1.\n");
                        return;
                    }
                    fseek(Sauve2, 0, SEEK_SET);
                    fprintf(Sauve2, "%d %d %d ", niveau, tempsRestant, score);
                    fseek(Sauve2, 0, SEEK_END);
                    //appel de niveau 1
                    clearScreen();
                    niveau1opt2();

                } else if (niveau2Info != 0) {
                    printf("Cette sauvegarde est deja utilise voulez vous l'ecraser?\n");
                    printf("1.Oui\n");
                    printf("2.Non\n");
                    scanf("%d", &reponse);
                    switch (reponse) {
                        case 1 :
                            fseek(Sauve2, 0, SEEK_SET);
                            fprintf(Sauve2, "%d %d %d\n", 0, 0, 0);
                            fseek(Sauve2, 3 * sizeof(int), SEEK_END);
                            //appel de niveau 1
                            clearScreen();
                            niveau1opt2();
                            break;
                        case 2 :
                            clearScreen();
                            chargementSauvegarde();
                            break;
                    }
                }

                break;

            case 3:
                Sauve3 = fopen("./Sauve3.txt", "w+");
                if (niveau3Info == 0) {


                    if (Sauve3 == NULL) {
                        printf("Erreur lors de l'ouverture du fichier pour sauvegarde du niveau 1.\n");
                        return;
                    }
                    fseek(Sauve3, 0, SEEK_SET);
                    fprintf(Sauve3, "%d %d %d\n", niveau, tempsRestant, score);
                    fseek(Sauve3, 0, SEEK_END);
                    clearScreen();
                    niveau1opt2();

                    // Écriture des données dans le fichier binaire
                    fprintf(Sauve3, "%d", niveau1());

                    fclose(Sauve3);


                    printf("Niveau enregistré dans le fichier binaire Sauve3\n");
                }
                else if (niveau3Info != 0) {
                    printf("Cette sauvegarde est deja utilise voulez vous l'ecraser?\n");
                    printf("1.Oui\n");
                    printf("2.Non\n");
                    scanf("%d", &reponse);
                    switch (reponse) {
                        case 1 :
                            fseek(Sauve1, 0, SEEK_SET);
                            fprintf(Sauve1, "%d %d %d ", 0, 0, 0);
                            fseek(Sauve1, 3 * sizeof(int), SEEK_END);
                            //appel de niveau 1
                            clearScreen();

                            niveau1opt2();
                            break;
                        case 2 :
                            clearScreen();
                            chargementSauvegarde();
                            break;
                    }
                }
            default :
                menuPrincipal();
                break;
        }

    }



void afficheSauvegarde(){
    int  dd1, dd2, dd3;
    int niveau1, niveau2, niveau3;
    int tempsRestant1, tempsRestant2, tempsRestant3 ;
    int score1, score2, score3;


    //ouverture fichier

    FILE *Sauve1;
    FILE *Sauve2;
    FILE *Sauve3;

    Sauve1=fopen("./Sauve1.txt", "r");
    Sauve2=fopen("./Sauve2.txt", "r");
    Sauve3=fopen("./Sauve3.txt", "r");

    //lecture fichier utilisé?
    fscanf(Sauve1,"%d",&dd1);
    fscanf(Sauve2,"%d",&dd2);
    fscanf(Sauve3,"%d",&dd3);

    //Se positionner pour trouver les infos du niveau
    fseek(Sauve1, 0, SEEK_SET);
    fseek(Sauve2, 0, SEEK_SET);
    fseek(Sauve3, 0, SEEK_SET);

    fscanf(Sauve1,"%d\t%d\t%d",&niveau1,&tempsRestant1,&score1);
    fscanf(Sauve2,"%d\t%d\t%d",&niveau2,&tempsRestant2,&score2);
    fscanf(Sauve3,"%d\t%d\t%d",&niveau3,&tempsRestant3,&score3);


//mess d'erreur
    if (Sauve1 == NULL|| Sauve2 == NULL|| Sauve3 == NULL) {
        printf("Erreur d'ouverture de fichier.");

    }
    //fermeture fichier lecture
    fclose(Sauve1);
    fclose(Sauve2);
    fclose(Sauve3);

//choix du fichier à charger

    printf("Sauvegarde 1\t :\t Niveau %d\tTemps restant : %d\tScore: %d\n",niveau1,tempsRestant1,score1);
    printf("Sauvegarde 2\t :\t Niveau %d\tTemps restant : %d\tScore: %d\n",niveau2,tempsRestant2,score2);
    printf("Sauvegarde 3\t :\t Niveau %d\tTemps restant : %d\tScore: %d\n",niveau3,tempsRestant3,score3);
}







int chargementSauvegarde() {
    int dd1, dd2, dd3, choixSauv = 0;

    //ouverture fichier


    FILE *Sauve1 =fopen("./Sauve1.txt", "r");

    FILE *Sauve2=fopen("./Sauve2.txt", "r");
    FILE *Sauve3 =fopen("./Sauve3.txt", "r");


    //Se positionner pour trouver les infos du niveau
    fseek(Sauve1, 0, SEEK_SET);
    fseek(Sauve2, 0, SEEK_SET);
    fseek(Sauve3, 0, SEEK_SET);
//lecture fichier utilisé?
    fscanf(Sauve1,"%d",&dd1);
    fscanf(Sauve2,"%d",&dd2);
    fscanf(Sauve3,"%d",&dd3);
    do {
        clearScreen();
        afficheSauvegarde();
        scanf("%d", &choixSauv);
    } while (choixSauv != 1 && choixSauv != 2 & choixSauv & 3);

//choix de sauvegarde

    switch (choixSauv) {
        case 1:
            Sauve1 = fopen("./Sauve1.txt", "a+");
            if (dd1 != 0) {

                if (Sauve1 == NULL) {
                    printf("erreur dans chargement sauvegarde");
                }
            } else if (dd1 == 0) {
                clearScreen();

                niveau1opt2();
            }
            break;
        case 2:
            Sauve2 = fopen("./Sauve2.txt", "a+");
            if (dd2 != 0) {

                if (Sauve2 == NULL) {
                    printf("erreur dans chargement sauvegarde");
                }
                else if (dd2 == 0) {
                    clearScreen();
                    niveau1opt2();
                }
                break;
                case 3:
                    Sauve3 = fopen("./Sauve3.txt", "a+");
                    if (dd3 != 0) {
                        clearScreen();

                        if (Sauve3 == NULL) {
                            printf("erreur dans chargement sauvegarde");
                        }


                    } else if (dd3 == 0) {
                        clearScreen();
                        Sauve3 = fopen("./Sauve3.txt", "w+");

                        if (Sauve3 == NULL) {
                            printf("erreur dans chargement sauvegarde");
                        }
                        clearScreen();
                        niveau1();


                    }
                default :
                    menuPrincipal();
                break;
            }
    }
}

