//Libraries
#include <stdio.h>
// 	permet de lire un caractère depuis l'entrée standard
//getchar()
#include <stdlib.h>
//exit()  	cause un arrêt normale du programme.
//system()La commande spécifiée par chaîne est transmise à l environnement hôte pour être exécuté par le processeur de commande.
#include <unistd.h>

#include <string.h>
//manipulation de chaînes
#include <windows.h> // sert pour la police et est propre à windows
#include <conio.h>

#include <stdbool.h>
#include <unistd.h>
#include <process.h>

//Structures


//Prototypes
void clearScreen();
void displayWithClear(const char *texte, unsigned int seconds);
void effacerEcranPartiel(char cadre[10][20], int hauteur, int largeur);
void hideCursor();
void Color(int couleurDuTexte,int couleurDeFond);
int vies0();


//affichage
void gameover();
void Reussi();
void Title();
void afficheSauvegarde();

//pour les options
void InfoNv1();
void InfoNv2();
void InfoNv3();
void InfoNv4();
void AttenteDebut(int niveau);
void Chronometre(void *params);
void togglePause(bool *isPaused);





////options
int menuPrincipal() ;
int regles();
int reglesp2();
int motdepasse();
int chargementSauvegarde();
int hiscore();


////scores
void comparateurScoreNv1(int a);
void comparateurScoreNv2 (int b);
void comparateurScoreNv3 (int c);
void comparateurScoreNv4 (int d);
void comparateurscoreTot(int e);
void scoreTot (int niveau, int score);
void reinitialiserScoreTot();


////sauvegardes
void sauvegarde( int niveau, int tempsRestant, int score);
void nouvellePartie(int niveau, int tempsRestant, int score);

////niveaux
int niveau1();
int niveau1opt2();
void initialiserGrilleniv1(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int positionY, int positionX);
void reinitialiserJeu1(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int *positionY,
                       int *positionX, int *tempsRestant, int *pInt);


int niveau2();
int niveau2opt2();
void initialiserGrilleniv2(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int positionY, int positionX);
void reinitialiserJeu2(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int *positionY, int *positionX, int *tempsRestant, int *vCount);


void initialiserGrilleniv3(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int positionY, int positionX);
void reinitialiserJeu3(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int *positionY, int *positionX, int *tempsRestant, int *vCount);
int niveau3opt2();
int niveau3();

int niveau4();
void reinitialiserJeu4(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int *positionY, int *positionX,  int *tempsRestant, int *vCount, int *balleY, int *balleX);
void initialiserGrilleniv4(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int positionY, int positionX);

