#include "plus.h"

#include <unistd.h>
#include <stdio.h>
#include <limits.h>
int hiscore() {
    int addition,scoreNv1=0,scoreNv2=0,scoreNv3=0,scoreNv4=0;
    FILE *TScoreNv1,*TScoreNv2, *TScoreNv3, *TScoreNv4, *scoreTot;

   //pour afficher le repertoire courant
   // https://stackoverflow.com/questions/298510/how-to-get-the-current-directory-in-a-c-program
   //
/*   char cwd[PATH_MAX];
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("Current working dir: %s\n", cwd);
    } else {
        perror("getcwd() error");
        return 1;
    }
  */
    TScoreNv1 = fopen("./TScoreNv1.txt", "r");
    TScoreNv2 = fopen("./TScoreNv2.txt", "r");
    TScoreNv3 = fopen("./TScoreNv3.txt", "r");
    TScoreNv4 = fopen("./TScoreNv4.txt", "r");
    scoreTot = fopen("./TScoreTot.txt", "r");
    if (TScoreNv1 == NULL|| TScoreNv2 == NULL|| TScoreNv3 == NULL|| TScoreNv4 == NULL||  scoreTot== NULL ) {
        perror("Erreur d'ouverture de fichier,hiscore.");
        sleep(200);
    }
    fscanf(TScoreNv1, "%d", &scoreNv1);
    fscanf(TScoreNv2, "%d", &scoreNv2);
    fscanf(TScoreNv3, "%d", &scoreNv3);
    fscanf(TScoreNv4, "%d", &scoreNv4);
    fscanf(scoreTot, "%d", &addition);


    fclose(TScoreNv1);
    fclose(TScoreNv2);
    fclose(TScoreNv3);
    fclose(TScoreNv4);
    fclose(scoreTot);


    printf("\t\tHIGH SCORE\n\n");

    printf("Niveau 1:\t%06d\n", scoreNv1);
    printf("Niveau 2:\t%06d\n",scoreNv2);
    printf("Niveau 3:\t%06d\n",scoreNv3);
    printf("Niveau 4:\t%06d\n\n\n",scoreNv4);
    printf("All Levels:\t%07d\n", addition);

    sleep(10);
    printf("Toucher une touche pour continuer");
    getch();
    clearScreen();
    menuPrincipal();
}

void comparateurScoreNv1 (int a) {
    int valeurs=0;

    FILE*TScoreNv1 = fopen("./TScoreNv1.txt", "w+");// ouvre le fichier monfichier.txt se trouvant à côté de l'exécutable
    //creation tableau dans le fichier
    if (TScoreNv1 == NULL) {

        printf("Erreur d'ouverture de fichier TScoreNv1");
        sleep(200);
    }
    fscanf(TScoreNv1, "%d", &valeurs);


    if (a >= valeurs) {
        fseek(TScoreNv1, 0, SEEK_SET);
        fprintf(TScoreNv1, "%8d ",a);
    }
    fclose(TScoreNv1);
}

void comparateurScoreNv2 (int b) {
    int valeurs=0;
    FILE *TScoreNv2 = fopen("./TScoreNv2.txt", "r+");// ouvre le fichier monfichier.txt se trouvant à côté de l'exécutable
//creation tableau dans le fichier
    if (TScoreNv2 == NULL) {
        printf("Erreur d'ouverture du fichier TScoreNv2");
        sleep(200);
    }

    fscanf(TScoreNv2, "%d", &valeurs);
    if (b >= valeurs) {
        fseek(TScoreNv2, 0, SEEK_SET);
        fprintf(TScoreNv2, "%8d ",b);
    }
    fclose(TScoreNv2);
}

void comparateurScoreNv3 (int c) {
    int valeurs=0;

    FILE *TScoreNv3 = fopen("./TScoreNv3.txt", "r+");// ouvre le fichier monfichier.txt se trouvant à côté de l'exécutable
//creation tableau dans le fichier
    if (TScoreNv3 == NULL) {
        printf("Erreur d'ouverture du fichier TScoreNv3");
        sleep(200);
    }
    fscanf(TScoreNv3, "%d", &valeurs);
    if (c >= valeurs) {
        fseek(TScoreNv3, 0, SEEK_SET);
        fprintf(TScoreNv3, "%8d ",c);
    }
    fclose(TScoreNv3);
}



void comparateurScoreNv4 (int d) {
    int valeurs=0;

    FILE * TScoreNv4 = fopen("./TScoreNv4.txt", "r+");// ouvre le fichier monfichier.txt se trouvant à côté de l'exécutable
//creation tableau dans le fichier
    if (TScoreNv4 == NULL) {
        printf("Erreur d'ouverture du fichier TScoreNv4");
        sleep(200);
    }
    fscanf(TScoreNv4, "%d", &valeurs);
    if (d >= valeurs) {
        fseek(TScoreNv4, 0, SEEK_SET);
        fprintf(TScoreNv4, "%8d ",d);
    }
    fclose(TScoreNv4);
}
void comparateurscoreTot(int e) {
    int valeurs = 0;

    FILE *TScoreTot = fopen("./TScoreTot.txt", "r+");

    if (TScoreTot == NULL) {
        printf("Erreur d'ouverture du fichier TScoreTot\n");
    }

    fscanf(TScoreTot, "%d", &valeurs);

    if (e >= valeurs) {
        fseek(TScoreTot, 0, SEEK_SET);
        fprintf(TScoreTot, "%d", e);
    }

    fclose(TScoreTot);
}
void reinitialiserScoreTot(){
        FILE *ScoreTotPt = fopen("./ScoreTot.txt", "w+");

        if (ScoreTotPt == NULL) {
            printf("Erreur d'ouverture du fichier ScoreTot\n");

        }
        fseek(ScoreTotPt, 0 , SEEK_SET);
    fprintf(ScoreTotPt, "%06d %06d %06d %06d ",0,0,0,0);
    fclose(ScoreTotPt);
}
void scoreTot(int niveau, int score) {
    int score1 = 0, score2 = 0, score3 = 0, score4 = 0, addition;
// ouvre le fichier monfichier.txt se trouvant à côté de l'exécutable
    FILE *ScoreTotPt = fopen("./ScoreTot.txt", "r+");

    if (ScoreTotPt == NULL) {
        printf("Erreur d'ouverture du fichier ScoreTot\n");

    }
    if (niveau==1){
        fseek(ScoreTotPt, 0 , SEEK_SET);
        fprintf(ScoreTotPt, "%05d ", score);
    }
    else if (niveau==2){
        fseek(ScoreTotPt, 6, SEEK_SET);
        fprintf(ScoreTotPt, "%05d ", score);
    }
    else if (niveau==3){
        fseek(ScoreTotPt, 12, SEEK_SET);
        fprintf(ScoreTotPt, "%05d ", score);
    }
    else if (niveau==4){
        fseek(ScoreTotPt, 18, SEEK_SET);
        fprintf(ScoreTotPt, "%05d ", score);
    }


    fseek(ScoreTotPt, 0 , SEEK_SET);
    fscanf(ScoreTotPt, "%05d %05d %05d %05d", &score1, &score2, &score3, &score4);

    addition = score1 + score2 + score3 + score4;


    fseek(ScoreTotPt, 24, SEEK_SET);
    fprintf(ScoreTotPt, "%05d ", addition);

    comparateurscoreTot(addition);

    fclose(ScoreTotPt);
}


