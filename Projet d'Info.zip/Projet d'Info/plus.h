//Libraries
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <windows.h>
#include <conio.h>
#include <stdbool.h>
#include <unistd.h>
#include <process.h>

//Structures


//Prototypes
void clearScreen();
void displayWithClear(const char *text, unsigned int seconds);
void hideCursor();
void InfoNv1();
void Chronometre(void* params);
void initialiserGrille(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int positionY, int positionX);
void reinitialiserJeu(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int *positionY, int *positionX,  int *tempsRestant);
void togglePause(bool *isPaused);




        int menuPrincipal() ;
int regles();
int reglesp2();
int motdepasse();


int sauvegarde();
int scoreNv1();
int scoreNv2();
int scoreNv3();
int scoreNv4();
int hiscore();


int niveau1();
