#include "plus.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Sommaires à faire

//afficher en ANSI
//Mettre des couleurs
//couleur des symboles: 'S'3, 'V'14, '$'4, 'C'8,'#'10->2

//Fonctions

//efface ce qui a deja ete ecrit
void clearScreen(){
    system("cls");
}


int vies0(){
    system("cls");

    printf("\x1b[1;10m\n");// Activer le texte en gras
    Color(4,0);
    gameover();
    Color(15,0);
    printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
    sleep(2);

    printf("Vous avez epuise vos vies\n");
    printf("Appuyez sur une touche pour revenir au menu principal\n");
    sleep(3);
}


//change la couleur de la police

void Color(int couleurDuTexte,int couleurDeFond) // fonction d'affichage de couleurs
{
    HANDLE H=GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(H,couleurDeFond*16+couleurDuTexte);
}


//https://stackoverflow.com/questions/15316455/how-to-change-font-size-in-console-application-using-c




//efface et affiche ligne suivante
void displayWithClear(const char *text, unsigned int seconds) {
    printf("%s", text);
    fflush(stdout);
    usleep(2 * 1000000); // ne se passe rien pour un temps donné
    printf("\r"); // curseur revient au debut de la ligne
    for (int i = 0; i < strlen(text); i++) {
        putchar(' '); // superpose les mots avec des espaces "efface"
    }
    printf("\r"); // curseur revient au debut de la ligne
}





//fonction qui permet de cacher le curseur de la souris, pour un affichage plus agréable
void hideCursor() {
    CONSOLE_CURSOR_INFO cursorInfo;
    cursorInfo.bVisible = false;
    cursorInfo.dwSize = 100;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
}


void gameover() {

    printf(" SSSSS       SS     SS    SS  SSSSSS      SSSSSS    S      S  SSSSSS  SSSSSS   \n");
    printf("S      S    S  S    SSS  SSS  SS         S      S   S      S  SS      S    S          \n");
    printf("S          S    S   S  SS  S  SSSS      S        S    S    S  SSSS    SSSSSS        \n");
    printf("S    SSS  S SSSS S  S      S  SSSS      S        S    S    S  SSSS    S   S           \n");
    printf("S     SS  S      S  S      S  SS         S      S      S   S  SS      S    S       \n");
    printf(" SSSSS    S      S  S      S  SSSSSS      SSSSSS        SSS   SSSSSS  S     S      \n");
    printf("\n\n");
}
void Reussi() {
    printf("SSSSSSS   SSSSSSS      SS     S      S    SSSSS       S   \n");
    printf("S     SS  S     S     S  S    S      S   S     S      S   \n");
    printf("S    SS   S SSS S    S    S     S    S  S       S     S   \n");
    printf("S   SSSS  S    S    S SSSS S    S    S  S       S     S      \n");
    printf("S      S  S     S   S      S     S   S   S     S             \n");
    printf("SSSSSSSS  S      S  S      S      SSS     SSSSS       S        \n");
    printf("\n\n");
}

void Title(){
    printf(" SSSSSS   SS     S    SSSSS      SSSSS    SSSSSSSS  S       S      \n");
    printf("SS        S S    S   S     S    S     S   S      S   S     S       \n");
    printf("  SSS     S S    S  S       S  S       S  S      S    S   S        \n");
    printf("    SSS   S  S   S  S       S  S       S  S SSSS       SSS         \n");
    printf("      SS  S  S   S   S     S    S     S   S             S          \n");
    printf("SSSSSS S  S   SS S    SSSSS      SSSSS    S             S          \n");
    printf("\n\n");
}


void InfoNv1(){
    printf("\tNIVEAU\t1\n");
    printf("Objectif:\n");
    printf("\t Temps:\t 120\n");
    printf("\n");
    hideCursor();
    Color(3,0);
    displayWithClear("S \t Snoopy                          ", 1);
    Color(14,0);
    displayWithClear("V \t Oiseaux a recuperer                          ", 1);
    Color(10,0);
    hideCursor();
    displayWithClear("# \t Bloc poussable 1 fois uniquement", 1);
    Color(8,0);
    hideCursor();
    displayWithClear("C \t Bloc cassable en appuyant sur C lorsque vous etes a cote du bloc", 1);
    Color(4,0);
    hideCursor();
    displayWithClear("$ \t Bloc piege, GAME OVER                                            ", 1);
    Color(15,0);
    hideCursor();
    printf("\n");
    printf("Touchez A pour commencer\n");
    hideCursor();

}
void InfoNv2(){
    printf("\tNIVEAU\t2\n");
    printf("Objectif:\n");
    printf("\t Temps:\t 120\n");
    printf("\n");
    hideCursor();
    Color(3,0);
    displayWithClear("S \t Snoopy                          ", 1);
    Color(14,0);
    displayWithClear("V \t Oiseaux a recuperer                          ", 1);
    Color(10,0);
    hideCursor();
    displayWithClear("# \t Bloc poussable 1 fois uniquement", 1);
    Color(8,0);
    hideCursor();
    displayWithClear("C \t Bloc cassable en appuyant sur C lorsque vous etes a cote du bloc", 1);
    Color(4,0);
    hideCursor();
    displayWithClear("$ \t Bloc piege, GAME OVER                                            ", 1);
    Color(15,0);
    hideCursor();
    printf("\n");
    printf("Touchez A pour commencer\n");
    hideCursor();

}
void InfoNv3(){
    printf("\tNIVEAU\t3\n");
    printf("Objectif:\n");
    printf("\t Temps:\t 120\n");
    printf("\n");
    hideCursor();
    Color(3,0);
    displayWithClear("S \t Snoopy                          ", 1);
    Color(14,0);
    displayWithClear("V \t Oiseaux a recuperer                          ", 1);
    Color(10,0);
    hideCursor();
    displayWithClear("# \t Bloc poussable 1 fois uniquement", 1);
    Color(8,0);
    hideCursor();
    displayWithClear("C \t Bloc cassable en appuyant sur C lorsque vous etes a cote du bloc", 1);
    Color(4,0);
    hideCursor();
    displayWithClear("$ \t Bloc piege, GAME OVER                                            ", 1);
    Color(15,0);
    hideCursor();
    printf("\n");
    printf("Touchez A pour commencer\n");
    hideCursor();

}
void InfoNv4(){
    printf("\tNIVEAU\t4\n");
    printf("Objectif:\n");
    printf("\t Temps:\t 120\n");
    printf("\n");
    hideCursor();
    Color(3,0);
    displayWithClear("S \t Snoopy                          ", 1);
    Color(14,0);
    displayWithClear("V \t Oiseaux a recuperer                          ", 1);
    Color(10,0);
    hideCursor();
    displayWithClear("# \t Bloc poussable 1 fois uniquement", 1);
    Color(8,0);
    hideCursor();
    displayWithClear("C \t Bloc cassable en appuyant sur C lorsque vous etes a cote du bloc", 1);
    Color(4,0);
    hideCursor();
    displayWithClear("$ \t Bloc piege, GAME OVER                                            ", 1);
    Color(15,0);
    hideCursor();
    printf("\n");
    printf("Touchez A pour commencer\n");
    hideCursor();

}
void AttenteDebut(int niveau) {
    char start;
    clearScreen();


        if (niveau==1){
            InfoNv1();

            sleep(2);
        }
        else if (niveau==2){
            InfoNv2();

            sleep(2);
        }
        else if (niveau==3){
            InfoNv3();

            sleep(2);
        }
        else if (niveau==4){
            InfoNv4();

            sleep(2);
        }
    while (1) {
        start = getch();
        if (start == 'a' || start == 'A') {
            break;
        }


    }
}

// Fonction du chronomètre
void Chronometre(void* params) {
    int* tempsRestant = (int*)params;

    while (*tempsRestant > 0) {
        Sleep(1000);  // Attendre 1 seconde
        (*tempsRestant)--;
    }
}

void togglePause(bool *isPaused) { //sous fonction qui permet de gerer la pause
    *isPaused = !*isPaused;
}




//menu principal
int menuPrincipal() {
    int option;
    clearScreen();

    printf("\n1.\t Regles du jeu \n");
    printf("2.\t Lancer un nouveau Jeu a partir du niveau 1 \n");
    printf("3.\t Charger une partie \n");
    printf("4.\t Mot de passe  \n");
    printf("5.\t Scores \n");
    printf("6.\t Quitter \n");
    scanf("%d", &option);
        clearScreen();
        if (option ==1){
            regles();
        }
        else if (option==2){
            //Commence a partir du niveau 1
            nouvellePartie(1,120,0);
        }
        else if (option ==3){
            clearScreen();
            printf("\tQuelle sauvegarde voulez vous charger?\n");
            chargementSauvegarde();
        }
        else if (option == 4){
            printf("Entrer le mot de passe\n");
            motdepasse();
        }
        else if (option==5){
            printf("Votre hi-score est de \n");
            hiscore();
        }
        else if (option==6){
            exit(0);
        }

        else {
            printf("choix invalide");
            menuPrincipal();
        }

}


//Affichage des regles page 1
int regles() {

    char quitter;
    printf("Les regles de la revanche de Snoopy (1/2): \n");
    printf("1.\tRejoignez les oiseaux dans le temps imparti \n");
    printf("2.\tNe touchez pas la balle, sinon vous perdez une vie \n");
    printf("3-\tVous avez 3 vies \n");
    printf("4-\tTapez ESP pour mettre pause \n");
    printf("5-\tCertains blocs sont a deplacer, a pousser ou  a eviter! \n");
    printf("6-\tUtilisez les fleches pour vous deplacer\n\n");
    printf("\n\n Tapez une touche pour afficher la page suivante\n");
    getch();
    clearScreen();

    return reglesp2();
}
//Affichage des regles page 2
int reglesp2() {

    char quitter;
    printf("Les regles de la revanche de Snoopy (2/2): \n");
    printf("\t\tInformations sur les symboles  \n");
    Color(3,0);
    printf("S \t ");
    Color(15,0);
    printf("Snoopy \n");
    Color(14,0);
    printf("V \t ");
    Color(15,0);
    printf("Oiseaux a recuperer\n");
    Color(10,0);
    printf("# \t ");
    Color(15,0);
    printf("Bloc poussable 1 fois uniquement \n");
    Color(8,0);
    printf("C \t ");
    Color(15,0);
    printf("Bloc cassable en appuyant sur C lorsque vous etes a cote du bloc\n");
    Color(4,0);
    printf("$ \t ");
    Color(15,0);
    printf("Bloc piege");
    Color(12,0);
    printf(", GAME OVER  \n\n");
    Color(15,0);
    getch();
    clearScreen();

    return menuPrincipal();
}



//les mots de passes qui menent aux niveaux
int motdepasse(){
    char mdp[7];//mdp a 7 chiffres + 0
    scanf("%6s", mdp);

    if (strcmp(mdp, "manger") == 0 || strcmp(mdp, "Manger") == 0 || strcmp(mdp, "MANGER") == 0) {

        clearScreen();
        printf("\tNIVEAU\t1\n");
        printf("Touchez A pour commencer\n");
        getch();
        niveau1();

    }

    else if (strcmp(mdp, "bloque") == 0 || strcmp(mdp, "Bloque") == 0 || strcmp(mdp, "BLOQUE") == 0) {

        clearScreen();
        printf("\tNIVEAU\t2\n");
        printf("Touchez A pour commencer\n");
        getch();
        niveau2();
    }

    else if (strcmp(mdp, "feutre") == 0 || strcmp(mdp, "Feutre") == 0 || strcmp(mdp, "FEUTRE") == 0) {

        clearScreen();
        printf("\tNIVEAU\t3\n");
        printf("Touchez A pour commencer\n");
        getch();
        niveau3();
    }

    else if (strcmp(mdp, "snoopy") == 0 || strcmp(mdp, "Snoopy") == 0 || strcmp(mdp, "SNOOPY") == 0) {

        clearScreen();
        printf("\tNIVEAU\t4\n");
        printf("Taper sur A pour commencer");
        getch();
        niveau4f();

    }
    else if (strcmp(mdp, "e") == 0 || strcmp(mdp, "E") == 0) {
        clearScreen();
        while (getchar() != '\n'); // Vider la mémoire tampon d'entrée
         menuPrincipal();

    }
    else{
        clearScreen();
        printf("Entrer le mot de passe ou taper E pour Exit au menu principal\n");
        motdepasse();
    }
}

void effacerEcranPartiel(char cadre[10][20], int hauteur, int largeur) { //fonction qui permet d'affacer partiellement l'ecran, afin d'eviter un clignotement
    COORD cursorPos; // Définir la position du curseur à l'angle supérieur gauche de la console
    cursorPos.X = 0;
    cursorPos.Y = 0;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cursorPos);

    for (int i = 0; i < hauteur; i++) { // Parcourir chaque ligne du cadre
        for (int j = 0; j < largeur; j++) { // Parcourir chaque colonne du cadre
            printf("%c", cadre[i][j]); // Afficher le caractère à la position actuelle dans le cadre
        }
        printf("\n");
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Main

int main() {
    //inititialisation

    //Affichage de début
    hideCursor();


    printf(" \n\n \t\tLA REVANCHE DE\n");
    Color(3, 0);

    Title();
    Color(15, 0);
    sleep(4);

    clearScreen();

    menuPrincipal();
}
