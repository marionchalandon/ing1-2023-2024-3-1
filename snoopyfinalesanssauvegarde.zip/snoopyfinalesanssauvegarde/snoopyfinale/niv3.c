#include "plus.h"

void initialiserGrilleniv3(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int positionY, int positionX) {
    for (int i = 0; i < hauteur; i++) {
        for (int j = 0; j < largeur; j++) {
            if (j == 0 || j == largeur - 1) {
                cadre[i][j] = 'X';
            } else if (i == 0 || i == hauteur - 1) {
                cadre[i][j] = 'X';
            } else {
                cadre[i][j] = ' ';
            }
            // Ajout des 'V' à chaque coin du cadre à l'intérieur
            if ((i == 1 && (j == 1 || j == largeur - 2)) || (i == hauteur - 2 && (j == 1 || j == largeur - 2))) {
                Color(15,0);
                cadre[i][j] = 'V';
            }
        }
    }

    for (int i = 0; i < hauteur; i++) {
        for (int j = 0; j < largeur; j++) {
            blocsPousses[i][j] = false;
        }
    }

    // Placer le pion au centre du tableau

    cadre[5][10] = 'S';

    cadre[1][3] = '#'; //affichage des blocs poussables autour de snoopy
    cadre[6][18] = '#';


    cadre[2][8] = 'C'; //affichage des blocs cassables
    cadre[3][8] = 'C';
    cadre[3][9] = 'C';


    cadre[2][1] = '$'; //affichage des blocs piégés
    cadre[8][2] = '$';
    cadre[1][17] = '$';
    cadre[8][17] = '$';
}

void reinitialiserJeu3(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int *positionY, int *positionX, int *tempsRestant, int *vCount) {
    // Réinitialiser le tableau
    initialiserGrilleniv3(cadre, blocsPousses, hauteur, largeur, 5, 10);
    *positionY = 5;
    *positionX = 10;
    *tempsRestant = 120; // Réinitialiser le chronomètre à 120 secondes
    *vCount = 4; // Réinitialiser le nombre d'oiseaux restants à 4
}

int niveau3(){
    //Affichage pour commencer niveau

    clearScreen();

//initialisation
    hideCursor();  // Masquer le curseur

    char cadre[10][20]; // Déclarer le tableau
    int largeur = 20;
    int hauteur = 10;
    int positionY = 5; // Position initiale X du pion (lignes)
    int positionX = 10; // Position initiale Y du pion (colonnes)
    int vCount = 4; // Nombre de 'V' restants
    int blocPousseY = -1; // Variables pour suivre la direction de poussée
    int blocPousseX = -1;
    bool blocsPousses[hauteur][largeur];
    int score = 0;
    int vies = 3;
    int b=0 ;
    char texte[50];
    bool gameOver = false;
    bool isPaused = false;  // Variable pour gérer la pause
    int tempsRestantPendantPause = 0; //variable qui suit le temps pendant la pause
    // Ajoutez une variable pour suivre si le message a déjà été affiché


    initialiserGrilleniv3(cadre, blocsPousses, hauteur, largeur, positionY, positionX); //appelle de la sous fonction pour initialise le tableau

    int tempsRestant = 120; // Chronomètre initialiser a 120 secondes

    // Créer un thread pour le chronomètre
    _beginthread(Chronometre, 0, &tempsRestant);


    while (1) {
        if (!isPaused) { //si la fonction pause n'est pas en marche, le temps defile et le joueur peut bouger
            effacerEcranPartiel(cadre, hauteur, largeur);
            printf("Temps restant : %d secondes\n", tempsRestant); //afficher le temps restants

            int a = 0;
            if (_kbhit()) { //fonction qui permet d'interagir avec le clavier de l'utilisateur
                a = getch(); // permet de lire un caractère sans que l'utilisateur appuie sur la touche Entrée
                if (a == ' ') {
                    togglePause(&isPaused); //on met le jeu en pause
                    tempsRestantPendantPause = tempsRestant; //on defini le temps restant comme le temps avant la pause
                }
            }


            printf("Deplacez le pion avec les fleches, Q (revenir au menu principal): "); //on affiche a l'utilisateur comment se deplacer
            printf("%d", a);//l'ordinateur recupere la touche pressée par l'utilisateur
            printf("\n\n rappel :\n V : oiseaux, $ : blocs piégés, C : blocs cassables, # : blocs poussables ");
            // Effacer la position actuelle du pion
            cadre[positionY][positionX] = ' ';

            // Mettre à jour la position du pion en fonction du déplacement
            if (a == 72 && positionY > 1 && !blocsPousses[positionY - 1][positionX] &&
                cadre[positionY - 1][positionX] != 'C') { //fleche du haut et on blinde pour pas sortir du cadre
                if (cadre[positionY - 1][positionX] == '$'){ //si la case dessus presente un piege
                    vies--; //l'utilisateur perds une vie
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    }
                    else if (vies >0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4,0);
                        gameover();
                        Color(15,0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vie", vies); //affichage du nombre de vies restantes
                        sleep(3);
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        getch();
                        clearScreen();
                        reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                          &vCount);
                    }
                } else {
                    positionY--;//sinon la joueur monte d'une case
                    blocPousseY = -1; // Pousse vers le haut
                    blocPousseX = 0;
                }
            } else if (a == 80 && positionY < hauteur - 2 && !blocsPousses[positionY + 1][positionX] &&
                       cadre[positionY + 1][positionX] != 'C') {//fleche du bas et on blinde pour pas sortir du cadre
                if (cadre[positionY + 1][positionX] == '$') {
                    vies--;
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    }
                    else if (vies >0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4,0);
                        gameover();
                        Color(15,0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vies", vies); //affichage du nombre de vies restantes
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                          &vCount);
                    }
                } else {
                    positionY++;
                    blocPousseY = 1; // Pousse vers le bas
                    blocPousseX = 0;
                }
            } else if (a == 75 && positionX > 1 && !blocsPousses[positionY][positionX - 1] &&
                       cadre[positionY][positionX - 1] !=
                       'C') { //fleche de gauche et on blinde pour pas sortir du cadre
                if (cadre[positionY][positionX - 1] == '$') {
                    vies--;
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    }
                    else if (vies >0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4,0);
                        gameover();
                        Color(15,0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vies", vies); //affichage du nombre de vies restantes
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                          &vCount);
                    }
                } else {
                    positionX--;
                    blocPousseY = 0;
                    blocPousseX = -1; // Pousse vers la gauche
                }
            } else if (a == 77 && positionX < largeur - 2 && !blocsPousses[positionY][positionX + 1] &&
                       cadre[positionY][positionX + 1] !=
                       'C') { //fleche de droite et on blinde pour pas sortir du cadre
                if (cadre[positionY][positionX + 1] == '$') {
                    vies--;
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                    }
                    else if (vies >0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4,0);
                        gameover();
                        Color(15,0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vies", vies); //affichage du nombre de vies restantes
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                          &vCount);
                    }
                } else {
                    positionX++;
                    blocPousseY = 0;
                    blocPousseX = 1; // Pousse vers la droite
                }
            } else if (a == 'm') { // si la touche m est pressée, on revient au menu
                reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant, &vCount);
                menuPrincipal(); // on appelle la fonction menu
            } else if (a == 'c') { // Si la touche "c" est pressée
                // Vérifiez si le pion est sur une case adjacente à un bloc "C"
                if ((positionY > 1 && cadre[positionY - 1][positionX] == 'C') ||
                    (positionY < hauteur - 2 && cadre[positionY + 1][positionX] == 'C') ||
                    (positionX > 1 && cadre[positionY][positionX - 1] == 'C') ||
                    (positionX < largeur - 2 && cadre[positionY][positionX + 1] == 'C')) {
                    // Vérifiez et supprimez les blocs "C" adjacents
                    if (positionY > 1 && cadre[positionY - 1][positionX] == 'C') {
                        cadre[positionY - 1][positionX] = ' ';
                    }
                    if (positionY < hauteur - 2 && cadre[positionY + 1][positionX] == 'C') {
                        cadre[positionY + 1][positionX] = ' ';
                    }
                    if (positionX > 1 && cadre[positionY][positionX - 1] == 'C') {
                        cadre[positionY][positionX - 1] = ' ';
                    }
                    if (positionX < largeur - 2 && cadre[positionY][positionX + 1] == 'C') {
                        cadre[positionY][positionX + 1] = ' ';
                    }
                }
            }

            if (cadre[positionY][positionX] == '#' && !blocsPousses[positionY][positionX] &&
                cadre[positionY + blocPousseY][positionX + blocPousseX] == ' ') {
                cadre[positionY + blocPousseY][positionX + blocPousseX] = '#';
                blocsPousses[positionY + blocPousseY][positionX + blocPousseX] = true;
                cadre[positionY][positionX] = ' ';
            }

            if (tempsRestant == 1) { //fonction si le le chrono arrive au bout
                vies--; //le joueur perds une vie
                if (vies == 0) { //si le joueur n'a plus de vie
                    vies0();
                    getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                    menuPrincipal();
                } else if (vies > 0) {
                    system("cls");
                    printf("le temps est écoulé, vous perdez une vie\n");
                    printf("il ne vous reste plus que %d vie\n", vies);
                    printf("\nAppuyez sur une touche pour recommencer...\n");
                    while (!_kbhit()) {
                    }
                    system("cls");
                    reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                      NULL);//on reinitialise le tableau
                    _beginthread(Chronometre, 0, &tempsRestant); //on reinitalise le chronometre
                }
            }


            if (cadre[positionY][positionX] == 'V') { //si le pion se trouve sur une case d'un oiseaux
                cadre[positionY][positionX] = ' '; //l'oiseau s'efface
                vCount--; //le nombre d'oiseaux reduit de 1
                if (vCount == 0) { //si le joueur a recuperer tout les oiseaux
                    system("cls"); // Effacer l'écran

                    printf("\x1b[1;10m\n");// Activer le texte en gras
                    Color(10,0);
                    Reussi();

                    printf(" NIVEAU REUSSI\n"); //le joueur a reussi le niveau
                    Color(15,0);
                    printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                    sleep(2);
                    score = tempsRestant * 100; //calcul du score en fonction du temps restants
                    printf("Score : %d\n", score);

                    scoreTot (3, score);
                    comparateurScoreNv3(score);
                    getch();
                    menuPrincipal();
                }
            }

            // Mettre à jour la position du pion sur le tableau
            cadre[positionY][positionX] = 'S';


        } else { //si le jeu est en pause
            COORD cursorPos; // Définir la position du curseur pour ue la phrase ne s'affiche qu'un seule fois
            cursorPos.X = 0;
            cursorPos.Y = 15;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cursorPos);
            printf("\nJEU EN PAUSE   Appuyez sur ESPACE pour reprendre et Q pour revenir au menu principal");
            //on affiche a l'utilisateur le jeu en pause


            int a = getch(); //on attneds que l'utilisateur re-appuye sur l'espace
            if (a == ' ') {
                Color(15, 0);
                printf("\r"); // curseur revient au debut de la ligne
                for (int i = 0; i < 86; i++) {
                    Color(15, 0);
                    putchar(' '); // superpose les mots avec des espaces "efface"
                }
                printf("\r"); // curseur revient au debut de la ligne

                togglePause(&isPaused); //on remet le jeu en marche
                tempsRestant = tempsRestantPendantPause; //le temps reprends la ou il etait avant la pause
            }
        }}

    // Rétablir l'affichage du curseur à la fin du programme
    CONSOLE_CURSOR_INFO cursorInfo;
    cursorInfo.bVisible = true;
    cursorInfo.dwSize = 1;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
}

int niveau3opt2() {
    //Affichage pour commencer niveau

    AttenteDebut(3);
    clearScreen();

//initialisation
    hideCursor();  // Masquer le curseur

    char cadre[10][20]; // Déclarer le tableau
    int largeur = 20;
    int hauteur = 10;
    int positionY = 5; // Position initiale X du pion (lignes)
    int positionX = 10; // Position initiale Y du pion (colonnes)
    int vCount = 4; // Nombre de 'V' restants
    int blocPousseY = -1; // Variables pour suivre la direction de poussée
    int blocPousseX = -1;
    bool blocsPousses[hauteur][largeur];
    int score = 0;
    int vies = 3;
    int b = 0;
    char texte[50];
    bool gameOver = false;
    bool isPaused = false;  // Variable pour gérer la pause
    int tempsRestantPendantPause = 0; //variable qui suit le temps pendant la pause
    // Ajoutez une variable pour suivre si le message a déjà été affiché
    int option;


    initialiserGrilleniv3(cadre, blocsPousses, hauteur, largeur, positionY,
                          positionX); //appelle de la sous fonction pour initialise le tableau

    int tempsRestant = 120; // Chronomètre initialiser a 120 secondes

    // Créer un thread pour le chronomètre
    _beginthread(Chronometre, 0, &tempsRestant);


    while (1) {
        if (!isPaused) { //si la fonction pause n'est pas en marche, le temps defile et le joueur peut bouger
            effacerEcranPartiel(cadre, hauteur, largeur);
            printf("Temps restant : %d secondes\n", tempsRestant); //afficher le temps restants


            int a = 0;
            if (_kbhit()) { //fonction qui permet d'interagir avec le clavier de l'utilisateur
                a = getch(); // permet de lire un caractère sans que l'utilisateur appuie sur la touche Entrée
                if (a == ' ') {
                    togglePause(&isPaused); //on met le jeu en pause
                    tempsRestantPendantPause = tempsRestant; //on defini le temps restant comme le temps avant la pause
                }
            }


            printf("Deplacez le pion avec les fleches, Q (revenir au menu principal): "); //on affiche a l'utilisateur comment se deplacer
            printf("%d", a);//l'ordinateur recupere la touche pressée par l'utilisateur
            printf("\n\n rappel :\n V : oiseaux, $ : blocs piégés, C : blocs cassables, # : blocs poussables ");
            // Effacer la position actuelle du pion
            cadre[positionY][positionX] = ' ';

            // Mettre à jour la position du pion en fonction du déplacement
            if (a == 72 && positionY > 1 && !blocsPousses[positionY - 1][positionX] &&
                cadre[positionY - 1][positionX] != 'C') { //fleche du haut et on blinde pour pas sortir du cadre
                if (cadre[positionY - 1][positionX] == '$') { //si la case dessus presente un piege
                    vies--; //l'utilisateur perds une vie
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    } else if (vies > 0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4, 0);
                        gameover();
                        Color(15, 0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vie", vies); //affichage du nombre de vies restantes
                        sleep(3);
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                          &vCount);
                    }
                } else {
                    positionY--;//sinon la joueur monte d'une case
                    blocPousseY = -1; // Pousse vers le haut
                    blocPousseX = 0;
                }
            } else if (a == 80 && positionY < hauteur - 2 && !blocsPousses[positionY + 1][positionX] &&
                       cadre[positionY + 1][positionX] != 'C') {//fleche du bas et on blinde pour pas sortir du cadre
                if (cadre[positionY + 1][positionX] == '$') {
                    vies--;
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    } else if (vies > 0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4, 0);
                        gameover();
                        Color(15, 0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vies", vies); //affichage du nombre de vies restantes
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                          &vCount);
                    }
                } else {
                    positionY++;
                    blocPousseY = 1; // Pousse vers le bas
                    blocPousseX = 0;
                }
            } else if (a == 75 && positionX > 1 && !blocsPousses[positionY][positionX - 1] &&
                       cadre[positionY][positionX - 1] !=
                       'C') { //fleche de gauche et on blinde pour pas sortir du cadre
                if (cadre[positionY][positionX - 1] == '$') {
                    vies--;
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    } else if (vies > 0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4, 0);
                        gameover();
                        Color(15, 0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vies", vies); //affichage du nombre de vies restantes
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                          &vCount);
                    }
                } else {
                    positionX--;
                    blocPousseY = 0;
                    blocPousseX = -1; // Pousse vers la gauche
                }
            } else if (a == 77 && positionX < largeur - 2 && !blocsPousses[positionY][positionX + 1] &&
                       cadre[positionY][positionX + 1] !=
                       'C') { //fleche de droite et on blinde pour pas sortir du cadre
                if (cadre[positionY][positionX + 1] == '$') {
                    vies--;
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    } else if (vies > 0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4, 0);
                        gameover();
                        Color(15, 0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vies", vies); //affichage du nombre de vies restantes
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                          &vCount);
                    }
                } else {
                    positionX++;
                    blocPousseY = 0;
                    blocPousseX = 1; // Pousse vers la droite
                }
            } else if (a == 'm') { // si la touche m est pressée, on revient au menu
                reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                  &vCount);
                menuPrincipal(); // on appelle la fonction menu
            } else if (a == 'c') { // Si la touche "c" est pressée
                // Vérifiez si le pion est sur une case adjacente à un bloc "C"
                if ((positionY > 1 && cadre[positionY - 1][positionX] == 'C') ||
                    (positionY < hauteur - 2 && cadre[positionY + 1][positionX] == 'C') ||
                    (positionX > 1 && cadre[positionY][positionX - 1] == 'C') ||
                    (positionX < largeur - 2 && cadre[positionY][positionX + 1] == 'C')) {
                    // Vérifiez et supprimez les blocs "C" adjacents
                    if (positionY > 1 && cadre[positionY - 1][positionX] == 'C') {
                        cadre[positionY - 1][positionX] = ' ';
                    }
                    if (positionY < hauteur - 2 && cadre[positionY + 1][positionX] == 'C') {
                        cadre[positionY + 1][positionX] = ' ';
                    }
                    if (positionX > 1 && cadre[positionY][positionX - 1] == 'C') {
                        cadre[positionY][positionX - 1] = ' ';
                    }
                    if (positionX < largeur - 2 && cadre[positionY][positionX + 1] == 'C') {
                        cadre[positionY][positionX + 1] = ' ';
                    }
                }
            }

            if (cadre[positionY][positionX] == '#' && !blocsPousses[positionY][positionX] &&
                cadre[positionY + blocPousseY][positionX + blocPousseX] == ' ') {
                cadre[positionY + blocPousseY][positionX + blocPousseX] = '#';
                blocsPousses[positionY + blocPousseY][positionX + blocPousseX] = true;
                cadre[positionY][positionX] = ' ';
            }

            if (tempsRestant == 1) { //fonction si le le chrono arrive au bout
                vies--; //le joueur perds une vie
                if (vies == 0) { //si le joueur n'a plus de vie
                    vies0();
                    getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                    menuPrincipal();
                } else if (vies > 0) {
                    system("cls");
                    printf("le temps est écoulé, vous perdez une vie\n");
                    printf("il ne vous reste plus que %d vie\n", vies);
                    printf("\nAppuyez sur une touche pour recommencer...\n");
                    while (!_kbhit()) {
                    }
                    system("cls");
                    reinitialiserJeu3(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant,
                                      NULL);//on reinitialise le tableau
                    _beginthread(Chronometre, 0, &tempsRestant); //on reinitalise le chronometre
                }
            }


            if (cadre[positionY][positionX] == 'V') { //si le pion se trouve sur une case d'un oiseaux
                cadre[positionY][positionX] = ' '; //l'oiseau s'efface
                vCount--; //le nombre d'oiseaux reduit de 1
                if (vCount == 0) { //si le joueur a recuperer tout les oiseaux
                    system("cls"); // Effacer l'écran

                    printf("\x1b[1;10m\n");// Activer le texte en gras
                    Color(10, 0);
                    Reussi();

                    printf(" NIVEAU REUSSI\n"); //le joueur a reussi le niveau
                    Color(15, 0);
                    printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                    sleep(2);
                    score = tempsRestant * 100; //calcul du score en fonction du temps restants
                    printf("Score : %d\n", score);
                    scoreTot (3, score);
                    comparateurScoreNv3(score);
                    printf("taper sur A pour passer au niveau suivant");
                    getch();
                    niveau4();
                }
            }

            // Mettre à jour la position du pion sur le tableau
            cadre[positionY][positionX] = 'S';


        } else { //si le jeu est en pause
            COORD cursorPos; // Définir la position du curseur pour ue la phrase ne s'affiche qu'un seule fois
            cursorPos.X = 0;
            cursorPos.Y = 15;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cursorPos);
            printf("\nJEU EN PAUSE   Appuyez sur ESPACE pour reprendre et Q pour revenir au menu principal");
            //on affiche a l'utilisateur le jeu en pause





            int a = getch(); //on attneds que l'utilisateur re-appuye sur l'espace
            if (a == ' ') {
                Color(15, 0);
                printf("\r"); // curseur revient au debut de la ligne
                for (int i = 0; i < 86; i++) {
                    Color(15, 0);
                    putchar(' '); // superpose les mots avec des espaces "efface"
                }
                printf("\r"); // curseur revient au debut de la ligne

                togglePause(&isPaused); //on remet le jeu en marche
                tempsRestant = tempsRestantPendantPause; //le temps reprends la ou il etait avant la pause
            }
        }
    }

    // Rétablir l'affichage du curseur à la fin du programme
    CONSOLE_CURSOR_INFO cursorInfo;
    cursorInfo.bVisible = true;
    cursorInfo.dwSize = 1;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);

}