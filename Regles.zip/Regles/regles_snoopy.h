//Libraries
#include <stdio.h>

//Structures


//Prototypes
int regles();