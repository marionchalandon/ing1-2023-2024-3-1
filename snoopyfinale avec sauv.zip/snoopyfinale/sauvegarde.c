#include "plus.h"
void afficheSauvegarde(){
    int niveau1=0, niveau2=0, niveau3=0;
    int tempsRestant1=0, tempsRestant2=0, tempsRestant3=0 ;
    int score1=0, score2=0, score3=0;
    int vie1=0,vie2=0,vie3=0;
    int save1=0,save2=0,save3=0;


    //ouverture fichier

    FILE *Sauve1;
    FILE *Sauve2;
    FILE *Sauve3;

    Sauve1=fopen("./Sauve1.txt", "r");
    Sauve2=fopen("./Sauve2.txt", "r");
    Sauve3=fopen("./Sauve3.txt", "r");


    //Se positionner pour trouver les infos du niveau
    fseek(Sauve1, 0, SEEK_SET);
    fseek(Sauve2, 0, SEEK_SET);
    fseek(Sauve3, 0, SEEK_SET);

    fscanf(Sauve1,"%d %d %d %5d %d",&save1, &niveau1, &tempsRestant1, &score1, &vie1);
    fscanf(Sauve2,"%d %d %d %5d %d",&save2, &niveau2, &tempsRestant2, &score2, &vie2);
    fscanf(Sauve3,"%d %d %d %5d %d",&save3, &niveau3, &tempsRestant3, &score3, &vie3);


//mess d'erreur
    if (Sauve1 == NULL|| Sauve2 == NULL|| Sauve3 == NULL) {
        printf("Erreur d'ouverture de fichier.");

    }
    //fermeture fichier lecture
    fclose(Sauve1);
    fclose(Sauve2);
    fclose(Sauve3);

//choix du fichier à charger

    printf("Sauvegarde 1\t :\t Niveau %d\tTemps restant : %d\tScore: %d\n",niveau1,tempsRestant1,score1);
    printf("Sauvegarde 2\t :\t Niveau %d\tTemps restant : %d\tScore: %d\n",niveau2,tempsRestant2,score2);
    printf("Sauvegarde 3\t :\t Niveau %d\tTemps restant : %d\tScore: %d\n",niveau3,tempsRestant3,score3);
}



void nouvellePartie(int niveau, int tempsRestant, int score) {
    int choixPartie, reponse = 0;
    FILE *Sauve1, *Sauve2, *Sauve3;
    int niveau1Info, niveau2Info, niveau3Info;

    /*char cwd[PATH_MAX];
    if (getcwd(cwd, sizeof(cwd)) != NULL) {
        printf("Current working dir: %s\n", cwd);
    } else {
        perror("getcwd() error");
        return 1;
    }*/
    //ouverture fichier

    Sauve1 = fopen("./Sauve1.txt", "r");
    Sauve2 = fopen("./Sauve2.txt", "r");
    Sauve3 = fopen("./Sauve3.txt", "r");

    //Se positionner pour trouver les infos du niveau
    fseek(Sauve1, 1, SEEK_SET);
    fseek(Sauve2, 1, SEEK_SET);
    fseek(Sauve3, 1, SEEK_SET);

    //lecture fichier utilisé?
    fscanf(Sauve1, "%d", &niveau1Info);
    fscanf(Sauve2, "%d", &niveau2Info);
    fscanf(Sauve3, "%d", &niveau3Info);

    //fermeture fichier lecture
    fclose(Sauve1);
    fclose(Sauve2);
    fclose(Sauve3);


        //choix de la sauvegarde

        do {
            clearScreen();

            printf("Veuillez choisir une sauvegarde pour votre nouvelle partie :\n");
            afficheSauvegarde();
            scanf("%d", &choixPartie);
        } while (choixPartie <= 0 || choixPartie > 3);

//choix de sauvegarde
        switch (choixPartie) {
            case 1:
                Sauve1=fopen("./Sauve1.txt", "w+");
                if (niveau1Info == 0) {


                    if (Sauve1 == NULL) {
                        printf("Erreur lors de l'ouverture du fichier pour sauvegarde du niveau 1.\n");
                        return;
                    }
                    fseek(Sauve1, 0, SEEK_SET);
                    fprintf(Sauve1, "%d %d %d %05d %d",1, 0, 0, 0, 3);
                    fseek(Sauve1, 0, SEEK_END);
                    //appel de niveau 1
                    clearScreen();
                    niveau1opt2(1);

                } else if (niveau1Info != 0) {
                    printf("Cette sauvegarde est deja utilise voulez vous l'ecraser?\n");
                    printf("1.Oui\n");
                    printf("2.Non\n");
                    scanf("%d", &reponse);
                    switch (reponse) {
                        case 1 :
                            fseek(Sauve1, 0, SEEK_SET);
                            fprintf(Sauve1, "%d %d %d %05d %d",1, 0, 0, 0, 3);
                            fseek(Sauve1, 3 * sizeof(int), SEEK_END);
                            //appel de niveau 1
                            clearScreen();
                            niveau1opt2(1);
                            break;
                        case 2 :
                            clearScreen();
                            chargementSauvegarde();
                            break;
                    }
                }
                fclose(Sauve1);
                break;
            case 2:

                Sauve2=fopen("./Sauve2.txt", "w+");
                if (niveau2Info == 0) {


                    if (Sauve2 == NULL) {
                        printf("Erreur lors de l'ouverture du fichier pour sauvegarde du niveau 1.\n");
                        return;
                    }
                    fseek(Sauve2, 0, SEEK_SET);
                    fprintf(Sauve2, "%d %d %d %05d %d",2, 0, 0, 0, 3);
                    fseek(Sauve2, 0, SEEK_END);
                    //appel de niveau 1
                    clearScreen();
                    niveau1opt2(2);

                } else if (niveau2Info != 0) {
                    printf("Cette sauvegarde est deja utilise voulez vous l'ecraser?\n");
                    printf("1.Oui\n");
                    printf("2.Non\n");
                    scanf("%d", &reponse);
                    switch (reponse) {
                        case 1 :
                            fseek(Sauve2, 0, SEEK_SET);
                            fprintf(Sauve2, "%d %d %d %5d %d",2, 0, 0, 0, 3);
                            fseek(Sauve2, 3 * sizeof(int), SEEK_END);
                            //appel de niveau 1
                            clearScreen();
                            niveau1opt2(2);
                            break;
                        case 2 :
                            clearScreen();
                            chargementSauvegarde();
                            break;
                    }
                }
                fclose(Sauve2);
                break;

            case 3:
                Sauve3 = fopen("./Sauve3.txt", "w+");
                if (niveau3Info == 0) {


                    if (Sauve3 == NULL) {
                        printf("Erreur lors de l'ouverture du fichier pour sauvegarde du niveau 1.\n");
                        return;
                    }
                    fseek(Sauve3, 0, SEEK_SET);
                    fprintf(Sauve3, "%d %d %d %5d %d",3, 0, 0, 0, 3);
                    fseek(Sauve3, 0, SEEK_END);
                    clearScreen();
                    niveau1opt2(3);



                }
                else if (niveau3Info != 0) {
                    printf("Cette sauvegarde est deja utilise voulez vous l'ecraser?\n");
                    printf("1.Oui\n");
                    printf("2.Non\n");
                    scanf("%d", &reponse);
                    switch (reponse) {
                        case 1 :
                            fseek(Sauve3, 0, SEEK_SET);
                            fprintf(Sauve3, "%d %d %d %5d %d",3, 0, 0, 0, 3);
                            fseek(Sauve3, 3 * sizeof(int), SEEK_END);
                            //appel de niveau 1
                            clearScreen();
                            niveau1opt2(3);
                            break;
                        case 2 :
                            clearScreen();
                            chargementSauvegarde();
                            break;
                    }
                }
                fclose(Sauve3);
            default :
                menuPrincipal();
                break;
        }

    }





void sauvegarde( int save ,char cadre[10][20], int niveau, int tempsRestant, int vCount, int vie) {


    FILE *SauveP1, *SauveP2, *SauveP3;


    if (save == 1) {

        SauveP1 = fopen("./Sauve1.txt", "w");


        fseek(SauveP1, 0, SEEK_SET);
        fprintf(SauveP1, "%d %d %d %5d %d ",save, niveau, tempsRestant, vCount, vie);

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 20; j++) {

                fprintf(SauveP1, "%c", cadre[i][j]);

            }
        }
        fclose(SauveP1);
    }
    else if (save == 2) {
        SauveP2 = fopen("./Sauve2.txt", "w");


        fseek(SauveP2, 0, SEEK_SET);
        fprintf(SauveP2, "%d %d %d %5d %d",save, niveau, tempsRestant, vCount, vie);

        fprintf(SauveP2,"\n");
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 20; j++) {

                fprintf(SauveP2, "%c", cadre[i][j]);

            }}
        fclose(SauveP2);
    }
    else if (save == 3) {
        SauveP3 = fopen("./Sauve3.txt", "w");
        fseek(SauveP3, 0, SEEK_SET);
        fprintf(SauveP3, "%d %d %d %5d %d",save, niveau, tempsRestant, vCount, vie);
        fprintf(SauveP3,"\n");
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 20; j++) {

                fprintf(SauveP1, "%c", cadre[i][j]);

            }}
        fclose(SauveP3);
    }
}



int chargementSauvegarde() {
        int dd1=0, dd2=0, dd3=0, choixSauv = 0;
        int Sauve = 1;
    int vCount = 1;
        char valeur;
        char cadre[10][20];
        int niveau = 0;
        int tempsRestant = 0;
        int score = 0;
        int vie = 0;




        FILE *SauveP1 = fopen("./Sauve1.txt", "r");
        FILE *SauveP2 = fopen("./Sauve2.txt", "r");
        FILE *SauveP3 = fopen("./Sauve3.txt", "r");

        fseek(SauveP1, 2, SEEK_SET);
        fseek(SauveP2, 2, SEEK_SET);
        fseek(SauveP3, 2, SEEK_SET);

        //lecture fichier utilisé?
        fscanf(SauveP1, "%d", &dd1);
        fscanf(SauveP2, "%d", &dd2);
        fscanf(SauveP3, "%d", &dd3);




        do {
            clearScreen();
            printf("Choisir la sauvegarde a charger\n");
            afficheSauvegarde();
            scanf("%d", &choixSauv);

        } while (choixSauv != 1 && choixSauv != 2 && choixSauv & 3);




//choix de sauvegarde

        if (choixSauv == 1) {
            if (SauveP1 == NULL) {
                printf("erreur dans chargement sauvegarde");
            }

                if (dd1== 0) {
                    clearScreen();
                    niveau1opt2(1);

                }
                else if (dd1== 1) {

                    fseek(SauveP1, 0, SEEK_SET);
                    fscanf(SauveP1,"%d %d %d %d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                fseek(SauveP1, 16, SEEK_SET);
                for (int i = 0; i < 10; i++) {
                    for (int j = 0; j < 20; j++) {

                        fscanf(SauveP1, "%c", &valeur);
                        cadre[i][j] = valeur;

                    }
                }
                niveau1Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                    fclose(SauveP1);
            }
            else if (dd1== 2) {
                clearScreen();
            fseek(SauveP1, 0, SEEK_SET);
                    fscanf(SauveP1,"%d %d %d %d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
            fseek(SauveP1, 17, SEEK_SET);
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 20; j++) {

                    fscanf(SauveP1, "%c", &valeur);
                    cadre[i][j] = valeur;

                }
            }
            clearScreen();
            niveau2Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
            fclose(SauveP1);
            }
                else if (dd1== 3) {
                    clearScreen();
                    fseek(SauveP1, 0, SEEK_SET);
                    fscanf(SauveP1,"%d %d %d %5d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                    fseek(SauveP1, 17, SEEK_SET);
                    for (int i = 0; i < 10; i++) {
                        for (int j = 0; j < 20; j++) {

                            fscanf(SauveP1, "%c", &valeur);
                            cadre[i][j] = valeur;

                        }
                    }
                    clearScreen();
                    niveau3Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                    fclose(SauveP1);
                }
                else if (dd1== 4) {
                    clearScreen();
                    fseek(SauveP1, 0, SEEK_SET);
                    fscanf(SauveP1,"%d %d %d %5d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                    fseek(SauveP1, 17, SEEK_SET);
                    for (int i = 0; i < 10; i++) {
                        for (int j = 0; j < 20; j++) {

                            fscanf(SauveP1, "%c", &valeur);
                            cadre[i][j] = valeur;

                        }
                    }
                    clearScreen();
                    niveau4Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                    fclose(SauveP1);
                }}


            else if (choixSauv == 2) {
                if (SauveP2 == NULL) {
                    printf("erreur dans chargement sauvegarde");
                }

                if (dd1== 0) {
                    clearScreen();
                    niveau1opt2(1);

                }
                else if (dd1== 1) {

                    fseek(SauveP2, 0, SEEK_SET);
                    fscanf(SauveP2,"%d %d %d %d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                    fseek(SauveP2, 17, SEEK_SET);
                    for (int i = 0; i < 10; i++) {
                        for (int j = 0; j < 20; j++) {

                            fscanf(SauveP2, "%c", &valeur);
                            cadre[i][j] = valeur;

                        }
                    }
                    clearScreen();
                    niveau1Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                    fclose(SauveP2);
                }
                else if (dd1== 2) {
                    clearScreen();
                    fseek(SauveP2, 0, SEEK_SET);
                    fscanf(SauveP2,"%d %d %d %5d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                    fseek(SauveP2, 17, SEEK_SET);
                    for (int i = 0; i < 10; i++) {
                        for (int j = 0; j < 20; j++) {

                            fscanf(SauveP2, "%c", &valeur);
                            cadre[i][j] = valeur;

                        }
                    }
                    clearScreen();
                    niveau2Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                    fclose(SauveP2);
                }
                else if (dd1== 3) {
                    clearScreen();
                    fseek(SauveP2, 0, SEEK_SET);
                    fscanf(SauveP2,"%d %d %d %5d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                    fseek(SauveP2, 17, SEEK_SET);
                    for (int i = 0; i < 10; i++) {
                        for (int j = 0; j < 20; j++) {

                            fscanf(SauveP2, "%c", &valeur);
                            cadre[i][j] = valeur;

                        }
                    }
                    clearScreen();
                    niveau3Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                    fclose(SauveP2);
                }
                else if (dd1== 4) {
                    clearScreen();
                    fseek(SauveP2, 0, SEEK_SET);
                    fscanf(SauveP2,"%d %d %d %5d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                    fseek(SauveP2, 17, SEEK_SET);
                    for (int i = 0; i < 10; i++) {
                        for (int j = 0; j < 20; j++) {

                            fscanf(SauveP2, "%c", &valeur);
                            cadre[i][j] = valeur;

                        }
                    }
                    clearScreen();
                    niveau4Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                    fclose(SauveP2);
                }}


                    else if (choixSauv == 3) {
                    if (SauveP3 == NULL) {
                        printf("erreur dans chargement sauvegarde");
                    }

                    if (dd1 == 0) {
                        clearScreen();
                        niveau1opt2(1);

                    } else if (dd1 == 1) {

                        fseek(SauveP3, 0, SEEK_SET);
                        fscanf(SauveP3,"%d %d %d %5d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                        fseek(SauveP3, 17, SEEK_SET);
                        for (int i = 0; i < 10; i++) {
                            for (int j = 0; j < 20; j++) {

                                fscanf(SauveP3, "%c", &valeur);
                                cadre[i][j] = valeur;

                            }
                        }
                        clearScreen();
                        niveau1Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                        fclose(SauveP3);
                    } else if (dd1 == 2) {
                        clearScreen();
                        fseek(SauveP3, 0, SEEK_SET);
                        fscanf(SauveP3,"%d %d %d %5d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                        fseek(SauveP3, 17, SEEK_SET);
                        for (int i = 0; i < 10; i++) {
                            for (int j = 0; j < 20; j++) {

                                fscanf(SauveP3, "%c", &valeur);
                                cadre[i][j] = valeur;

                            }
                        }
                        clearScreen();
                        niveau2Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                        fclose(SauveP3);
                    } else if (dd1 == 3) {
                        clearScreen();
                        fseek(SauveP3, 0, SEEK_SET);
                        fscanf(SauveP3,"%d %d %d %5d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                        fseek(SauveP3, 17, SEEK_SET);
                        for (int i = 0; i < 10; i++) {
                            for (int j = 0; j < 20; j++) {

                                fscanf(SauveP3, "%c", &valeur);
                                cadre[i][j] = valeur;

                            }
                        }
                        clearScreen();
                        niveau3Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                        fclose(SauveP3);
                    } else if (dd1 == 4) {
                        clearScreen();
                        fseek(SauveP3, 0, SEEK_SET);
                        fscanf(SauveP3,"%d %d %d %5d %d",&Sauve, &niveau, &tempsRestant, &vCount, &vie);
                        fseek(SauveP3, 17, SEEK_SET);
                        for (int i = 0; i < 10; i++) {
                            for (int j = 0; j < 20; j++) {

                                fscanf(SauveP3, "%c", &valeur);
                                cadre[i][j] = valeur;

                            }
                        }
                        clearScreen();
                        niveau4Charge(Sauve, cadre, niveau, tempsRestant, vCount, vie);
                        fclose(SauveP3);
                    }
                }

else{
    menuPrincipal();
}

    }