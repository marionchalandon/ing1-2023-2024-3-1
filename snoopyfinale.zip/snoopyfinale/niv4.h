#include "plus.h"
void initialiserGrilleniv4(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int positionY, int positionX) {
    for (int i = 0; i < hauteur; i++) {
        for (int j = 0; j < largeur; j++) {
            if (j == 0 || j == largeur - 1) {
                cadre[i][j] = 'X';
            } else if (i == 0 || i == hauteur - 1) {
                cadre[i][j] = 'X';
            } else {
                cadre[i][j] = ' ';
            }
            // Ajout des 'V' à chaque coin du cadre à l'intérieur
            if ((i == 1 && (j == 1 || j == largeur - 2)) || (i == hauteur - 2 && (j == 1 || j == largeur - 2))) {
                Color(14,0);
                cadre[i][j] = 'V';
            }
        }
    }

    for (int i = 0; i < hauteur; i++) {
        for (int j = 0; j < largeur; j++) {
            blocsPousses[i][j] = false;
        }
    }

    // Placer le pion au centre du tableau

    cadre[5][10] = 'S';

    cadre[5][2] = '#'; //affichage des blocs poussables autour de snoopy
    cadre[7][2] = '#';
    cadre[8][16] = '#';

    cadre[1][3] = 'C'; //affichage des blocs cassables
    cadre[2][3] = 'C';
    cadre[5][1] = 'C';
    cadre[1][13] = 'C';
    cadre[5][12] = 'C';
    cadre[6][12] = 'C';
    cadre[1][16] = 'C';
    cadre[1][17] = 'C';
    cadre[2][16] = 'C';
    cadre[2][17] = 'C';
    cadre[2][18] = 'C';
    cadre[3][16] = 'C';
    cadre[3][17] = 'C';
    int balleY =5;
    int balleX =5;

    // Placer la balle au centre du tableau
    cadre[balleY][balleX] = 'b';

    cadre[1][4] = '$'; //affichage des blocs piégés
    cadre[3][1] = '$';
    cadre[3][3] = '$';
    cadre[4][3] = '$';
    cadre[5][3] = '$';
    cadre[6][3] = '$';
    cadre[8][3] = '$';
    cadre[6][1] = '$';
    cadre[2][11] = '$';
    cadre[6][11] = '$';
    cadre[3][13] = '$';
    cadre[4][14] = '$';
    cadre[8][13] = '$';
    cadre[4][16] = '$';
    cadre[6][16] = '$';
    cadre[5][17] = '$';
    cadre[6][17] = '$';
    cadre[7][17] = '$';

}


void reinitialiserJeu4(char cadre[10][20], bool blocsPousses[10][20], int hauteur, int largeur, int *positionY, int *positionX,  int *tempsRestant, int *vCount, int *balleY, int *balleX) { //sous fonction qui permet de reinitaliser le jeu (placement et chrono)
    // Réinitialiser le tableau
    *vCount = 4;
    initialiserGrilleniv4(cadre, blocsPousses, hauteur, largeur, 5, 10);
    *positionY = 5;
    *positionX = 10;
    *tempsRestant = 120; // Réinitialiser le chronomètre à 120 secondes
    // Reset the position of the ball to its initial coordinates
    *balleY = 5;
    *balleX = 5;
    cadre[*balleY][*balleX] = 'b';
}



int niveau4(){
    //Affichage pour commencer niveau

    AttenteDebut();
    clearScreen();

//initialisation
    hideCursor();  // Masquer le curseur

    char cadre[10][20]; // Déclarer le tableau
    int largeur = 20;
    int hauteur = 10;
    int positionY = 5; // Position initiale X du pion (lignes)
    int positionX = 10; // Position initiale Y du pion (colonnes)
    int vCount = 4; // Nombre de 'V' restants
    int blocPousseY = -1; // Variables pour suivre la direction de poussée
    int blocPousseX = -1;
    bool blocsPousses[hauteur][largeur];
    int score = 0;
    int vies = 3;
    int b=0 ;
    char texte[50];
    bool gameOver = false;
    bool isPaused = false;  // Variable pour gérer la pause
    int tempsRestantPendantPause = 0; //variable qui suit le temps pendant la pause
    // Ajoutez une variable pour suivre si le message a déjà été affiché
    int balleX = 5; // Position initiale de la balle (colonne)
    int balleY = 5; // Position initiale de la balle (ligne)
    int directionX = 1; // Direction de la balle sur l'axe des colonnes (+1 vers la droite, -1 vers la gauche)
    int directionY = 1; // Direction de la balle sur l'axe des lignes (+1 vers le bas, -1 vers le haut)



    initialiserGrilleniv4(cadre, blocsPousses, hauteur, largeur, positionY, positionX); //appelle de la sous fonction pour initialise le tableau

    int tempsRestant = 120; // Chronomètre initialiser a 120 secondes

    // Créer un thread pour le chronomètre
    _beginthread(Chronometre, 0, &tempsRestant);


    while (1) {
        if (!isPaused) { //si la fonction pause n'est pas en marche, le temps defile et le joueur peut bouger
            effacerEcranPartiel(cadre, hauteur, largeur);
            printf("Temps restant : %d secondes\n", tempsRestant); //afficher le temps restants

            int a = 0;
            if (_kbhit()) { //fonction qui permet d'interagir avec le clavier de l'utilisateur
                a = getch(); // permet de lire un caractère sans que l'utilisateur appuie sur la touche Entrée
                if (a == ' ') {
                    togglePause(&isPaused); //on met le jeu en pause
                    tempsRestantPendantPause = tempsRestant; //on defini le temps restant comme le temps avant la pause
                }
            }



            printf("Deplacez le pion avec les fleches, Q (revenir au menu principal): "); //on affiche a l'utilisateur comment se deplacer
            printf("%d", a);//l'ordinateur recupere la touche pressée par l'utilisateur
            printf("\n\n rappel :\n V : oiseaux, $ : blocs piégés, C : blocs cassables, # : blocs poussables ");
            // Effacer la position actuelle du pion
            cadre[positionY][positionX] = ' ';
            // Effacer la position actuelle de la balle
            // Effacer la position actuelle de la balle sauf si la nouvelle position est un bloc
            // Effacer la position actuelle de la balle sauf si la nouvelle position est un bloc
            if (cadre[balleY][balleX] != '#' && cadre[balleY][balleX] != 'C' && cadre[balleY][balleX] != '$') {
                cadre[balleY][balleX] = ' ';
            }



            // Vérifier les collisions avec les murs et les autres objets
            if (balleX == 1 || balleX == 18) {
                directionX = -directionX;
                balleX += directionX;  // Mettre à jour la position de la balle
            }

            if (balleY == 1 || balleY == 8) {
                directionY = -directionY;
                balleY += directionY;  // Mettre à jour la position de la balle
            }



            // Mettre à jour la position du pion en fonction du déplacement
            if (a == 72 && positionY > 1 && !blocsPousses[positionY - 1][positionX] &&
                cadre[positionY - 1][positionX] != 'C') { //fleche du haut et on blinde pour pas sortir du cadre
                if (cadre[positionY - 1][positionX] == '$'){ //si la case dessus presente un piege
                    vies--; //l'utilisateur perds une vie
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    }
                    else if (vies >0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4,0);
                        gameover();
                        Color(15,0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vie", vies); //affichage du nombre de vies restantes
                        sleep(3);
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu4(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant, &vCount, &balleY, &balleX);
                    }
                } else {
                    positionY--;//sinon la joueur monte d'une case
                    blocPousseY = -1; // Pousse vers le haut
                    blocPousseX = 0;
                    // Mettre à jour la position de la balle
                    balleX += directionX;
                    balleY += directionY;
                }
            } else if (a == 80 && positionY < hauteur - 2 && !blocsPousses[positionY + 1][positionX] &&
                       cadre[positionY + 1][positionX] != 'C') {//fleche du bas et on blinde pour pas sortir du cadre
                if (cadre[positionY + 1][positionX] == '$') {
                    vies--;
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    }
                    else if (vies >0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4,0);
                        gameover();
                        Color(15,0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vies", vies); //affichage du nombre de vies restantes
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu4(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant, &vCount, &balleY, &balleX);
                    }
                } else {
                    positionY++;
                    blocPousseY = 1; // Pousse vers le bas
                    blocPousseX = 0;
                    // Mettre à jour la position de la balle
                    balleX += directionX;
                    balleY += directionY;
                }
            } else if (a == 75 && positionX > 1 && !blocsPousses[positionY][positionX - 1] &&
                       cadre[positionY][positionX - 1] !=
                       'C') { //fleche de gauche et on blinde pour pas sortir du cadre
                if (cadre[positionY][positionX - 1] == '$') {
                    vies--;
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    }
                    else if (vies >0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4,0);
                        gameover();
                        Color(15,0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vies", vies); //affichage du nombre de vies restantes
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu4(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant, &vCount, &balleY, &balleX);
                    }
                } else {
                    positionX--;
                    blocPousseY = 0;
                    blocPousseX = -1; // Pousse vers la gauche
                    // Mettre à jour la position de la balle
                    balleX += directionX;
                    balleY += directionY;
                }
            } else if (a == 77 && positionX < largeur - 2 && !blocsPousses[positionY][positionX + 1] &&
                       cadre[positionY][positionX + 1] !=
                       'C') { //fleche de droite et on blinde pour pas sortir du cadre
                if (cadre[positionY][positionX + 1] == '$') {
                    vies--;
                    if (vies == 0) {
                        vies0();
                        getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                        menuPrincipal();
                    }
                    else if (vies >0) {
                        system("cls");//la console s'efface
                        printf("\x1b[1;10m\n");// Activer le texte en gras
                        Color(4,0);
                        gameover();
                        Color(15,0);
                        printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                        sleep(2);

                        printf("Il vous reste %d vies", vies); //affichage du nombre de vies restantes
                        printf("\nAppuyez sur une touche pour recommencer...\n");
                        while (!_kbhit()) { //fonction pour attendre que l'utilisateur appuie sur une touche
                        }
                        clearScreen();
                        reinitialiserJeu4(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant, &vCount, &balleY, &balleX);
                    }
                } else {
                    positionX++;
                    blocPousseY = 0;
                    blocPousseX = 1; // Pousse vers la droite
                    // Mettre à jour la position de la balle
                    balleX += directionX;
                    balleY += directionY;
                }
            } else if (a == 'm') { // si la touche m est pressée, on revient au menu
                menuPrincipal(); // on appelle la fonction menu
            } else if (a == 'c') { // Si la touche "c" est pressée
                // Vérifiez si le pion est sur une case adjacente à un bloc "C"
                if ((positionY > 1 && cadre[positionY - 1][positionX] == 'C') ||
                    (positionY < hauteur - 2 && cadre[positionY + 1][positionX] == 'C') ||
                    (positionX > 1 && cadre[positionY][positionX - 1] == 'C') ||
                    (positionX < largeur - 2 && cadre[positionY][positionX + 1] == 'C')) {
                    // Vérifiez et supprimez les blocs "C" adjacents
                    if (positionY > 1 && cadre[positionY - 1][positionX] == 'C') {
                        cadre[positionY - 1][positionX] = ' ';
                    }
                    if (positionY < hauteur - 2 && cadre[positionY + 1][positionX] == 'C') {
                        cadre[positionY + 1][positionX] = ' ';
                    }
                    if (positionX > 1 && cadre[positionY][positionX - 1] == 'C') {
                        cadre[positionY][positionX - 1] = ' ';
                    }
                    if (positionX < largeur - 2 && cadre[positionY][positionX + 1] == 'C') {
                        cadre[positionY][positionX + 1] = ' ';
                    }
                }
            }

            if (cadre[positionY][positionX] == '#' && !blocsPousses[positionY][positionX] &&
                cadre[positionY + blocPousseY][positionX + blocPousseX] == ' ') {
                cadre[positionY + blocPousseY][positionX + blocPousseX] = '#';
                blocsPousses[positionY + blocPousseY][positionX + blocPousseX] = true;
                cadre[positionY][positionX] = ' ';
            }

            if (tempsRestant == 1) { //fonction si le le chrono arrive au bout
                vies--; //le joueur perds une vie
                if (vies == 0) { //si le joueur n'a plus de vie
                    vies0();
                    getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                    menuPrincipal();
                } else if (vies > 0) {
                    system("cls");
                    printf("le temps est écoulé, vous perdez une vie\n");
                    printf("il ne vous reste plus que %d vie\n", vies);
                    printf("\nAppuyez sur une touche pour recommencer...\n");
                    while (!_kbhit()) {
                    }
                    system("cls");
                    reinitialiserJeu4(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant, &vCount, &balleY, &balleX);
                    _beginthread(Chronometre, 0, &tempsRestant); //on reinitalise le chronometre
                }
            }
            if (balleY == positionY && balleX == positionX) {
                // La balle touche Snoopy
                vies--;
                if (vies == 0) {
                    vies0();
                    getch();
                    menuPrincipal();
                } else {
                    system("cls");
                    printf("Snoopy a été touché par la balle !\n");
                    printf("Il vous reste %d vies.\n", vies);
                    printf("Appuyez sur une touche pour continuer...\n");
                    while (!_kbhit()) {
                        // Attendre que l'utilisateur appuie sur une touche
                    }
                    clearScreen();
                    reinitialiserJeu4(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant, &vCount, &balleY, &balleX);
                }
            }


            if (cadre[positionY][positionX] == 'V') { //si le pion se trouve sur une case d'un oiseaux
                cadre[positionY][positionX] = ' '; //l'oiseau s'efface
                vCount--; //le nombre d'oiseaux reduit de 1
                if (vCount == 0) { //si le joueur a recuperer tout les oiseaux
                    system("cls"); // Effacer l'écran

                    printf("\x1b[1;10m\n");// Activer le texte en gras
                    Color(10,0);
                    Reussi();

                    printf(" NIVEAU REUSSI\n"); //le joueur a reussi le niveau
                    Color(15,0);
                    printf("\x1b[0m \n"); // Rétablir la mise en forme par défaut
                    sleep(2);


                    score = tempsRestant * 100; //calcul du score en fonction du temps restants
                    printf("Score : %d\n", score);
                    sleep(5);
                    printf("Appuyez sur une touche pour revenir au menu principal...\n");
                    getch(); // Attendre que l'utilisateur appuie sur une touche pour quitter
                    menuPrincipal();
                }
            }



            // Mettre à jour la position du pion sur le tableau
            Color(3,0);
            cadre[positionY][positionX] = 'S';
            Color(15,0);


            // Afficher la balle à sa nouvelle position si ce n'est pas un bloc
            if (cadre[balleY][balleX] != '#' && cadre[balleY][balleX] != 'C' && cadre[balleY][balleX] != '$') {
                cadre[balleY][balleX] = 'b';
            }

        } else { //si le jeu est en pause
            Color(15, 8);
            COORD cursorPos; // Définir la position du curseur pour ue la phrase ne s'affiche qu'un seule fois
            cursorPos.X = 0;
            cursorPos.Y = 15;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cursorPos);
            printf("\nJEU EN PAUSE   Appuyez sur ESPACE pour reprendre et Q pour revenir au menu principal");
            //on affiche a l'utilisateur le jeu en pause
                                                                                                                                                                         

            int a = getch(); //on attneds que l'utilisateur re-appuye sur l'espace
            if (a == ' ') {
                Color(15, 0);
                printf("\r"); // curseur revient au debut de la ligne
                for (int i = 0; i < 86; i++) {
                    Color(15, 0);
                    putchar(' '); // superpose les mots avec des espaces "efface"
                }
                printf("\r"); // curseur revient au debut de la ligne

                togglePause(&isPaused); //on remet le jeu en marche
                tempsRestant = tempsRestantPendantPause; //le temps reprends la ou il etait avant la pause
            }
        }}

    // Rétablir l'affichage du curseur à la fin du programme
    CONSOLE_CURSOR_INFO cursorInfo;
    cursorInfo.bVisible = true;
    cursorInfo.dwSize = 1;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);

    reinitialiserJeu4(cadre, blocsPousses, hauteur, largeur, &positionY, &positionX, &tempsRestant, &vCount, &balleY, &balleX);

    return menuPrincipal();//retour au menu principal

}