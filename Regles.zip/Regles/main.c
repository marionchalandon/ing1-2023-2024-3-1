#include "regles_snoopy.h"


int regles() {

    char quitter;
    printf("Les regles de la revanche de Snoopy: \n");
    printf("1.\tRejoignez les oiseaux dans le temps imparti \n");
    printf("2.\tNe touchez pas la balle, sinon vous perdez une vie \n");
    printf("3-\tVous avez 3 vies \n");
    printf("4-\tCertains blocs seront a deplacer, a pousser ou  a eviter!  \n\n");
    printf("\tLes touches : \n\n");
    printf("\t \t \t Z \n\n");
    printf("\t \t Q\t S\t D");
    printf("\n Toucher Q pour revenir au menu principal");
    scanf("%c",&quitter);
    while (quitter!='q' && quitter!='Q')
    {scanf("%c",&quitter);}

    return 0;
}
int main() {
   regles();

    return 0;
}
